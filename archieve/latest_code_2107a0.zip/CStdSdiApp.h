
class CStdSdiApp: public CWinApp
{
public:
	BOOL InitInstance();
};